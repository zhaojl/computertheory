package com.zjl.demo.client

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.LocalSocket
import android.net.LocalSocketAddress
import android.util.Log
import com.zjl.demo.R
import com.zjl.demo.SerializableBitmap
import java.io.InputStream
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.io.OutputStream
import java.util.concurrent.Executors

object ClientSocket {

    private var clientSocket: LocalSocket? = null

    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null

    private var executor = Executors.newSingleThreadExecutor()
    private var bitmap: Bitmap? = null
    private var totalSpentTime = 0L

    fun startClient(application: Application) {
        try {
            clientSocket = LocalSocket()
            clientSocket?.connect(LocalSocketAddress("me.linjw.localsocket"))

            bitmap = BitmapFactory.decodeResource(application.resources, R.drawable.demo_aaa)

            inputStream = clientSocket?.inputStream
            outputStream = clientSocket?.outputStream

            sendAndReceiveData()

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun sendAndReceiveData() {
        val socket = clientSocket ?: return
        for (i in 1..100) {
            executor.submit {
                try {
                    val startTime = System.currentTimeMillis()
                    val out = ObjectOutputStream(socket.outputStream)
                    val serializableBitmap = SerializableBitmap(bitmap)
                    out.writeObject(serializableBitmap)
                    out.flush()
                    Log.d("demo_client", "client sendData $i: $serializableBitmap")

                    val spentTime = System.currentTimeMillis() - startTime
                    totalSpentTime += spentTime

                } catch (e: Throwable) {
                    Log.e("xxx", "xxx", e)
                }
            }

            executor.submit {
                val startTime = System.currentTimeMillis()
                val objInput = ObjectInputStream(socket.inputStream)
                val obj = objInput.readObject()
                if (obj is SerializableBitmap) {
                    Log.d("demo_client", "client receiveData $i: $obj")
                }

                val spentTime = System.currentTimeMillis() - startTime
                totalSpentTime += spentTime
            }
        }
    }

    private fun receiveData() {
        val socket = clientSocket ?: return
        for (i in 1..100) {
            executor.submit {
                val objInput = ObjectInputStream(socket.inputStream)
                val obj = objInput.readObject()
                if (obj is SerializableBitmap) {
                    Log.d("demo_client", "client receiveData $i: $obj")
                }
            }
        }
    }

    fun close() {
        clientSocket?.close()
    }


}