package com.zjl.demo.server

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.LocalServerSocket
import android.net.LocalSocket
import android.util.Log
import com.zjl.demo.R
import com.zjl.demo.SerializableBitmap
import com.zjl.demo.client.ClientSocket
import java.io.InputStream
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.io.OutputStream
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.Future

object ServerSocket {

    private const val TAG = "demo_server"

    private var localServerSocket: LocalServerSocket? = null
    private var localSocket: LocalSocket? = null

    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null

    private var executor = Executors.newSingleThreadExecutor()
    private var bitmap: Bitmap? = null

    private var totalSpentTime: Long = 0L


    fun startServer(application: Application) {
        try {
            localServerSocket = LocalServerSocket("me.linjw.localsocket")

            localSocket = localServerSocket?.accept()
            bitmap = BitmapFactory.decodeResource(application.resources, R.drawable.demo_bbb)

            inputStream = localSocket?.inputStream
            outputStream = localSocket?.outputStream

            sendAndReceiveData()

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun sendAndReceiveData() {
        val socket = localSocket ?: return
        for (i in 1..100) {
            val futureReceive: Future<Long> = executor.submit(Callable<Long> {
                val startTime = System.currentTimeMillis()
                val objInput = ObjectInputStream(socket.inputStream)
                val obj = objInput.readObject()
                if (obj is SerializableBitmap) {
                    Log.d(TAG, "server receiveData $i: $obj")
                }

                val spentTime = System.currentTimeMillis() - startTime
                totalSpentTime += spentTime
                totalSpentTime
            })

            val futureSend: Future<Long> = executor.submit(Callable<Long> {
                val startTime = System.currentTimeMillis()
                val out = ObjectOutputStream(socket.outputStream)
                val serializableBitmap = SerializableBitmap(bitmap)
                out.writeObject(serializableBitmap)
                out.flush()
                Log.d(TAG, "server sendData $i: $serializableBitmap")

                val spentTime = System.currentTimeMillis() - startTime
                totalSpentTime += spentTime
                totalSpentTime
            })

            if (i == 100) {
                Log.d(TAG, "lastReceive: ${futureReceive.get()}")
                Log.d(TAG, "lastSend: ${futureSend.get()}")
            }
        }
    }

    private fun sendData() {
        val socket = localSocket ?: return
        for (i in 1..100) {
            executor.execute {
                try {
                    val out = ObjectOutputStream(socket.outputStream)
                    val serializableBitmap = SerializableBitmap(bitmap)
                    out.writeObject(serializableBitmap)
                    out.flush()
                    Log.d("demo_server", "server sendData $i: $serializableBitmap")
                } catch (e: Throwable) {
                    Log.e("demo_server", "xxx", e)
                }
            }
        }
    }

    fun close() {
        localSocket?.close()
        localServerSocket?.close()
    }
}